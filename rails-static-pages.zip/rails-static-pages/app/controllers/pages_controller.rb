class PagesController < ApplicationController
  def home
  end

  def about
  end

  def help
  end

  def contact
  end

end
